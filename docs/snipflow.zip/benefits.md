# Benefits

> What using SnipFlow gets you as a development team

SnipFlow gives your team a simple way to connect everything together, standard places to review your work in various stages (and easy ways to deploy to them), as well as standardising the terminology you use, so that communication becomes easier and everyday tasks become simpler and less risky.

## Easy onboarding

## Clean versioning

## Transparency

## Communication
